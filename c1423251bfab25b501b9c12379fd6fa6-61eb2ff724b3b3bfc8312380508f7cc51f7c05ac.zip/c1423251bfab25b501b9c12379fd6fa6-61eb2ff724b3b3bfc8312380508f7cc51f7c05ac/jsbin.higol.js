var dht;
var rgbled;


boardReady({device: 'kXNG'}, function (board) {
  board.samplingInterval = 100;
  dht = getDht(board, 12);
  rgbled = getRGBLedCathode(board, 2, 4, 7);
  rgbled.setColor('#000000');
  document.getElementById("demo-area-01-show").style.fontSize = 20+"px";
  document.getElementById("demo-area-01-show").style.lineHeight = 20+"px";
  dht.read(function(evt){
    document.getElementById("demo-area-01-show").innerHTML = (['溫度：',dht.temperature,'度<br/>濕度：',dht.humidity,'%'].join(''));
    if (dht.humidity >= 60) {
      rgbled.setColor('#ff0000');
    }
    else
      {
        rgbled.setColor('#33ff33');
      }
  }, 1000);
});